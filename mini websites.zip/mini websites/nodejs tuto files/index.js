var superheroes = require("superheroes");
var myname= superheroes.random();
console.log(myname);