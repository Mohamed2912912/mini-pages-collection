$("button").click(function(){
    $("h1").slideToggle();
})