
$(".title").mouseenter( function(){
    $(this).animate({ margin: -20, width: "+=20", height: "+=20" });
});
$(".title").mouseleave( function(){
    $(this).animate({ margin: 0, width: "-=20", height: "-=20" });
});



$("#order").click( function(){
    $("#contact").hide();
    $("#thanks").show();
});