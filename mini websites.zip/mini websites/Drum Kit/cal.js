function Housewife(name, grooms, bed_skills,aids,clean){
    this.name= name;
    this.grooms=grooms;
    this.bed_skills= bed_skills;
    this.aids= aids;
    this.clean= function () {
        alert("cleanning in progress...")
    }

}