//kaiji
var number1 = Math.floor(Math.random()*6+1);
var kaiji = "images/dice"+number1+".png";
document.querySelectorAll("img")[0].setAttribute("src",kaiji);


//tonegawa
var number2 = Math.floor(Math.random()*6+1);
var tonegawa = ("images/dice"+number2+".png");
document.querySelectorAll("img")[1].setAttribute("src",tonegawa);


//messages displayed

if (number1>number2)
{
    document.querySelector("h1").textContent = "kaiji wins!";
}

    if (number2>number1)
{
    document.querySelector("h1").textContent = "kaiji, is dead!";
}
if (number2==number1){
    document.querySelector("h1").textContent = "it's a tie!!!";
}