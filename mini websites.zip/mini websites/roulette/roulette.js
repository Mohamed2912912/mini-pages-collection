var i=0;
var double0 =1; 
var double1 =1;
var blackWins = 0; 
var blackLoses = 0; 
var redWins = 0; 
var redLoses = 0; 
var black = 0; 
var red = 0; 
var totalWins = 0; 

 var x = Number(prompt ("write the amount of small bet you want to gamble with:")); 
  var y = Number(prompt ("write the number of spins you want to gamble on:")); 
  console.log("you will gamble with: "+x+"$, for: "+y+"spins");
  var spinarray = []; 
  var k = 0; 
  var j = 0; 
  var color = ["red", "black"]; 
  while  (i <y ){i ++
      var spin = Math.floor (Math.random () * 2); 
      var randomChosenColour = color [spin]; 
      spinarray.push.randomChosenColour; 

      console.log ("spin number" + i + " has came as:" + randomChosenColour); 





      // the color out is red 
      if (spin === 0) {j ++ 
        if (spinarray [i] !== spinarray [i-1]) {
          redWins = redWins + (x* double1);
          blackLoses = blackLoses- x;
          

        } else{
 
          redWins = redWins + x;
          blackLoses = blackLoses- ( x* double0); 
          double0 = double0 * 2;
          double1=1;
     }
     black = blackWins + blackLoses; 
     red = redWins + redLoses;
     console.log("red"+red ,"black"+black , "doubl0= "+double0, "double1= "+double1)}
    

    
    // the color out is black
      if (spin === 1) {k ++ 
      if (spinarray [i] !== spinarray [i-1]) {
        blackWins = blackWins + (x * double0);
        redLoses = redLoses-x;
        

} else{

  blackWins = blackWins + x; 
  redLoses = redLoses- (x * double1); 
  double1 = double1 * 2; 
  double0=1;  

    }
    black = blackWins + blackLoses; 
    red = redWins + redLoses;
    console.log("red"+red ,"black"+black , "doubl0= "+double0, "double1= "+double1)}
    
    
   


      
    } //end of the loop
    double0=1;
    double1=1;



      console.log ("the black has been resulted:" + k + "times"); 
      console.log ("the red has been resulted:" + j + "times"); 
 
      console.log ("total black money is:" + black + "$"); 
      console.log ("total red money is:" + red + "$"); 

      totalWins = black + red;
      console.log ("total money won by this amazing algorithm is:" + totalWins + "$ !!!!");
 alert ("congratulations! you won:" + totalWins + "$");



