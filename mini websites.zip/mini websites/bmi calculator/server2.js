const express =require("express");
const app = express();
const bodyparser = require("body-parser");

app.use(bodyparser.urlencoded({extended:true}));

app.get("/", function(req , res){
    
    res.sendFile(__dirname+"/bmi.html");
});

app.listen(3100, function(){
    console.log("check");
});

app.post("/",function(req ,res){

var wieght1=Number(req.body.wieght);
var hieght1=Number(req.body.hieght);

var h2= hieght1*hieght1;
var bmi=wieght1/h2;

res.send("Your BMI is: "+bmi);


});