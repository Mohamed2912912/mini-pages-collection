const express = require("express");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({extended: true}));




app.get("/", function(req, res){
res.sendFile(__dirname + "/indexx.html");
});

app.post("/", function(req , res){

var n11= Number(req.body.N1);
var n22= Number(req.body.N2);
var result = n11*n22;

console.log(req.body.N1);
console.log(req.body.N2);


res.send("this is ur result:"+result);
});


app.listen(4000, function(){
    console.log("just to make sure and double check");
});
