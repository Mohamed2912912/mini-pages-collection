
var buttonColours=[ "red", "blue", "green", "yellow", "white", "cyan","purpel", "orange", "pink","orange2","green2","marron"];



var gamePattern=[];
var userClickedPatttern=[];


var started=false;
var level=-1;

$(document).keydown(function(){
  if (!started){
    $("#level-title").text("score is: "+level);
  nextSequence();
  started=true;
  }
});

$(".btn").click(function() {

  var userChosenColour= $(this).attr("id");

  userClickedPattern.push(userChosenColour);
  playSound(userChosenColour);
  animatepress(userChosenColour);
  
  
  checkAnswer(userClickedPattern.length-1);

});

function checkAnswer(currentLevel){

  if (gamePattern[currentLevel]=== userClickedPattern[currentLevel]){
    if (userClickedPattern.length ===gamePattern.length){
      setTimeout(function(){
        nextSequence();
      },500);
    }
  }
  else {

    highscorechecker(level);
    playSoundWrong("wrong");
    
     $("body").addClass("game-over");
     $("nav").addClass("gameover");
     $("#level-title").html("Game over, you passed: "+levelf(level));

    setTimeout(function(){
      $("body").removeClass("game-over");
      $("nav").removeClass("gameover");
    },250);
  
    startOver();
  
  }
  }

function nextSequence(){
  userClickedPattern=[];
  level++;
  $("#level-title").text("score is: "+level);
  var randomNumber= Math.floor(Math.random()*12);
  var randomChosenColour=buttonColours[randomNumber];
  gamePattern.push(randomChosenColour);

  $("#"+randomChosenColour).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100);

  playSound(randomChosenColour);

}


function animatepress(currentColor){
  
  $("#"+currentColor).addClass("pressed");
  setTimeout(function(){
    $("#"+currentColor).removeClass("pressed");},100);
  
  }

  function startOver(){
    level=-1;
    gamePattern=[];
    started =false;
    }

//neeeds a bit of editing/

function playSound(name){

  var music=new Audio("sounds/"+name+".mp3");
  music.play();
}


  function playSoundWrong(name2){

      var wrong1=new Audio('sounds/'+name2+'.mp3');
      wrong1.play();
  }


function levelf(level){
  if (level<=5){
  var kaiji= level+" rounds, ASSHOLE! press 'space' to restart";}
if(level<=8&&level>5){
  kaiji=level+" rounds, you are a MEDIUM-PLAYER!  press 'space' to restart";
}
if(level<=14&&level>8){
  kaiji=level+" rounds, you are a CHAMPION!  press 'space' to restart";
}
if(level>14){
  kaiji=level+" rounds, you are a LEGEND!  press 'space' to restart";
}
  return kaiji;
}

function highscorechecker(score){

console.log(score);
}






$("#here").click( function(){
  $("#not decided yet").hide();
  $("#thanks").show();
});