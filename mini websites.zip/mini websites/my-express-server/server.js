const express = require("express");
const app = express();


app.get("/", function(req , res){
    console.log(req);
    res.send("<h1>moh is the best<h1\>");
});

app.get("/gettingabout", function(req, res){
res.send("<ul><li>b<li\><li>k<li\><ul\>");
});

app.get("/italia", function(req, res){
res.send("this is italia by moh");
});



app.listen(5000, function(){
    console.log("that's totally normal.")
});

